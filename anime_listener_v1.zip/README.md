# Anime Japanese Listener

TV Japanese audio → laptop microphone → Chrome speech recognition → Gemini → Japanese + romaji + English + grammar breakdown.

## Deploy on Vercel

1. Upload this folder to a GitHub repository.
2. Import that repo into Vercel.
3. Go to Project Settings → Environment Variables.
4. Add `GEMINI_API_KEY` with your Gemini API key.
5. Redeploy.
6. Open the URL in desktop Chrome.
7. Click Start listening and allow microphone access.

## Local

Run:

npm install
npx vercel dev

Create `.env.local` containing:

GEMINI_API_KEY=your_key_here

The key stays server-side.
